// rsf
// 필요한 React 기능 및 라이브러리를 임포트합니다.
import React from 'react';
import axios from 'axios';
import { useState, useEffect } from 'react';
import {useParams, useHistory} from 'react-router-dom';
import "../css/postdetail.css";

function PostDetail() {
// post 상태를 관리하기 위한 useState 훅. 초기 상태는 빈 객체입니다.
    const [post, setPost] = useState({});
// useParams 훅을 사용하여 URL 파라미터 중 boardNumber를 추출합니다.
    const{boardNumber} = useParams();
// useHistory 훅을 사용하여 history 객체를 가져옵니다.
// 이 객체를 통해 브라우저의 history를 조작할 수 있습니다.
    const history = useHistory();

    // 컴포넌트가 마운트될 때와 boardNumber가 변경될 때 실행될 useEffect 훅.
    useEffect(() => {
        // fetchPost는 비동기 함수로, axios를 사용하여 게시글의 상세 정보를 불러옵니다.
        const fetchPost = async() => {
            try{                
                // 게시글의 ID(boardNumber)를 이용하여 해당 게시글의 상세 정보를 요청합니다.
                // 아래에서 `는 백틱 키를 의미합니다. ' 홀따옴표를 하시면 에러가 나타납니다.
                // 왜냐하면 탬플릿 문자열 ${} 표현이 있기 때문입니다.
                const response = await axios.get(`http://localhost:9008/api/posts/${boardNumber}`);
                //응답으로 받은 데이터를 post 상태에 저장합니다.
                setPost(response.data);
            } catch(error){
                // 요청이 실패한 경우, 오류를 콘솔에 출력합니다.
                console.log(error);
                alert("처리에 오류가 발생했습니다!");
            }
        };
        // fetchPost 함수를 호출하여 실행합니다.
        fetchPost();
    }, [boardNumber]); // useEffect는 boardNumber가 변경될 때마다 재실행합니다.

    // 글목록으로 이동하는 함수
    const goToPostList = () => {
        // history.puch를 사용하여 '/' 경로로 페이지를 전환합니다.
        history.push(`/postlist`);
    };

    const handleUpdate = async() => {
        try{
            // 작성자 정보(boardWriter)는 수정에서 제외하고
            // 업데이트 데이터를 준비합니다.
            const {boardWriter, ...updateData} = post;
            // 수정된 데이터를 서버에 PUT 요청으로 전송합니다.
            await axios.put(`http://localhost:9008/api/posts/${boardNumber}`, updateData);
            alert('게시글이 수정되었습니다!'); // 게시글수정 성공 알림
            history.push('/postlist'); // 메인 페이지로 이동 처리함
        } catch(error){
            alert('게시글 수정 실패!'); // 게시글수정 성공 알림
            console.error("게시글 수정 실패", error);
          
        }
    };
     // 글수정 이동하는 함수
     const goToPostEdit = () => {
        history.push(`/edit/${post.boardNumber}`); // 게시글목록으로 이동합니다.
    };

    const handleDelete = async(boardNumber) => {
        // if문을 활용하여, 삭제 전 사용자에게 확인(confirm)을 요청합니다.
        if(window.confirm("게시글을 삭제하시겠습니까?")){
            try{
                await axios.delete(`http://localhost:9008/api/posts/${boardNumber}`);
                alert('게시글이 삭제되었습니다.'); // 삭제 완료 알림
                history.push('/postlist');
            } catch (error){
                // 삭제 실패 시 콘솔에 에러 로그를 남립니다.
                console.error('게시글 삭제 실패', error);
                alert('게시글 삭제에 실패했습니다!');
            }
        }
    };

    return (
        
        <div className='inner'>
            <div className='in'>
            <div className='wrapper'>
                <h2 className='Sboard'>Staff <br/>Community  </h2>
            </div>
            {/* 게시글의 제목을 표시합니다! */}
            <div className='viewHead'>
                <h2 className='subject'>{post.boardTitle}</h2>
                {/* 게시글의 내용을 표시합니다! */}
            </div>  
            <div className='viewBody'>  
                <p className='viewCon'>{post.boardContents}</p>
                {/* 게시글의 작성자를 표시합니다! */}
            </div>
            <div className='viewFo'>
                <p className='viewWri'>작성자 : {post.boardWriter}</p>
                {/* 버튼 클릭 시 글목록 페이지로 이동 */}
            </div>
            <div className='btnWrap'>

               <div className='funBtn'> <li onClick={goToPostList} className='EBtn'>글목록으로 이동</li></div>
               <div className='funBtn'> <li type='button' onClick={goToPostEdit}className='MBtn'>수정 처리</li></div>
               <div className='funBtn'> <li onClick={() => handleDelete(post.boardNumber)} className='DBtn'>게시글 삭제</li></div>
            </div>
                <br />

            </div>
        </div>
    );
}

export default PostDetail;