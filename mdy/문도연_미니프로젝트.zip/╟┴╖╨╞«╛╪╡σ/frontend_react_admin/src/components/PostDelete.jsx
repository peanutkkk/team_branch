// rsf
import React, { useState } from 'react';
import axios from 'axios';
import {Link, useHistory} from 'react-router-dom';
import "../css/postdelete.css";
function PostDelete() {

    const[posts, setPosts] = useState([]);

    const history = useHistory();

    // 백엔드에서 게시글 목록을 조회하는 함수
    const fetchPosts = async() => {
        try{
            console.log('게시글 목록 조회 요청 시작');
            const response = await axios.get('http://localhost:9008/api/posts');
            console.log('응답 데이터:', response.data);
            // 서버로부터 받은 데이터를 직접 상태에 저장
            setPosts(response.data); 
        } catch(error){
            console.error("게시글 목록 조회 에러", error);
            alert("게시글 목록 조회 실패!");
        }
    };

    // 게시글을 삭제하는 함수입니다.
    const handleDelete = async(boardNumber) => {
        // if문을 활용하여, 삭제 전 사용자에게 확인(confirm)을 요청합니다.
        if(window.confirm("게시글을 삭제하시겠습니까?")){
            try{
                await axios.delete(`http://localhost:9008/api/posts/${boardNumber}`);
                alert('게시글이 삭제되었습니다.'); // 삭제 완료 알림
                fetchPosts(); // 삭제 처리 후에 게시글 목록을 다시 조회합니다.
            } catch (error){
                // 삭제 실패 시 콘솔에 에러 로그를 남립니다.
                console.error('게시글 삭제 실패', error);
                alert('게시글 삭제에 실패했습니다!');
            }
        }
    };


    return (
        <div>
            <h2>게시글 목록</h2>      
            <button onClick={fetchPosts}>게시글 목록 조회</button>
            <ul>
                {posts.map(post => (
                    <li key={post.boardNumber}>
                        {/* 게시글 제목을 클릭하면 해당 게시글의 상세 페이지로 이동하게 합니다.
                        아래에서 `는 백틱 키를 의미합니다. ' 홀따옴표를 하시면 에러가 나타납니다.
                        왜냐하면 탬플릿 문자열 ${} 표현이 있기 때문입니다. */}
                        <Link to={`/posts/${post.boardNumber}`}>
                            <h3>{post.boardTitle}</h3>
                        </Link>
                        {/* 게시글 수정 페이지로 이동하는 버튼을 생성합니다.
                        아래에서 `는 백틱 키를 의미합니다. ' 홀따옴표를 하시면 에러가 나타납니다.
                        왜냐하면 탬플릿 문자열 ${} 표현이 있기 때문입니다. */}
                        <button onClick={() => history.push(`/edit/${post.boardNumber}`)} >게시글 수정</button>
                        <button onClick={() => handleDelete(post.boardNumber)}>게시글 삭제</button>
                        <p>{post.boardContents}</p>
                        <p>작성자 : {post.boardWriter}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default PostDelete;