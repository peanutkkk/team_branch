// src/components/CartPage.js
import React from 'react';
import { useCart } from './CartContext'; // CartContext 임포트
import { Link } from 'react-router-dom';

const CartPage = () => {
  const { cart, removeFromCart } = useCart(); // cart와 removeFromCart 함수 사용

  return (
    <div>
      <h1>장바구니</h1>
      {cart.length === 0 ? (
        <p>장바구니에 상품이 없습니다.</p>
      ) : (
        <ul>
          {cart.map((product) => (
            <li key={product.productNumber}>
              <h2>{product.productName}</h2>
              <p>{product.productDescription}</p>
              <p>Seller: {product.seller}</p>
              {product.imagePath && (
                <img src={product.imagePath} alt={product.productName} style={{ maxWidth: '100%', height: 'auto' }} />
              )}
              <button onClick={() => removeFromCart(product.productNumber)}>제거</button>
            </li>
          ))}
        </ul>
      )}
      <Link to="daum_kakao_addr_02">주소찾기</Link><br></br>
      <Link to="/payment">결제하기</Link><br></br>
      <Link to="/">홈으로 돌아가기</Link>
      <br />
      <Link to="/products">리스트로 돌아가기</Link>
    </div>
  );
};

export default CartPage;
