import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';
import '../css/PostDetail.css'; // 커스텀 CSS 파일

function PostDetail() {
    const [post, setPost] = useState({});
    const { boardNumber } = useParams();
    const history = useHistory();
    const [posts, setPosts] = useState([]);

    const handleDelete = async (boardNumber) => {
        if (window.confirm("게시글을 삭제하시겠습니까?")) {
            try {
                await axios.delete(`http://localhost:9008/api/posts/${boardNumber}`);
                alert('게시글이 삭제되었습니다.');
                fetchPosts(); // 삭제 처리 후에 게시글 목록을 다시 조회합니다.
                history.push('/'); // 메인 페이지로 이동 처리함
            } catch (error) {
                console.error('게시글 삭제 실패', error);
                alert('게시글 삭제에 실패했습니다!');
            }
        }
    };

    const fetchPosts = async () => {
        try {
            console.log('게시글 목록 조회 요청 시작');
            const response = await axios.get('http://localhost:9008/api/posts');
            console.log('응답 데이터:', response.data);
            // 서버로부터 받은 데이터를 직접 상태에 저장
            setPosts(response.data);
        } catch (error) {
            console.error("게시글 목록 조회 에러", error);
            alert("게시글 목록 조회 실패!");
        }
    };

    useEffect(() => {
        const fetchPost = async() => {
            try {
                const response = await axios.get(`http://localhost:9008/api/posts/${boardNumber}`);
                setPost(response.data);
            } catch(error) {
                console.log(error);
                alert("처리에 오류가 발생했습니다!");
            }
        };
        fetchPost();
    }, [boardNumber]);

    const goToPostList = () => {
        history.push('/');
    };

    return (
        <div className="container">
            <h2>{post.boardTitle}</h2>
            <p className='author'>작성자 : {post.boardWriter}</p>
            <p>{post.boardContents}</p>
            <div className="button-group">
                <button className="editBtn" onClick={() => history.push(`/edit/${post.boardNumber}`)}>게시글 수정</button>
                <button className="listBtn" onClick={goToPostList}>글목록으로 이동</button>
                <button className="deleteBtn" onClick={() => handleDelete(post.boardNumber)}>게시글 삭제</button>
            </div>
        </div>
    );
}

export default PostDetail;
