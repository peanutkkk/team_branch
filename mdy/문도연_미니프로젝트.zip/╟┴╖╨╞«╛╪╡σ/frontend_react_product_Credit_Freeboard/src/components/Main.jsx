import React from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom';

function Main() {
    return (
        <div>
            <h1>메인페이지입니다.</h1>
            <Link to='/product'> 상품리스트로 go</Link><br></br>
            <Link to='/posts'> 게시글리스트로 go</Link>
        </div>
    );
}

export default Main;