import React from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

function Home(props) {
    return (
        <div>
            <h3>홈입니다</h3>
            <Link to='/products'>상품페이지로 이동</Link>
        </div>
    );
}

export default Home;