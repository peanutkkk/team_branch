// 이 패키지 선언은 현재 클래스가 com.springboot.react.config 패키지 내에 위치함을 나타냅니다.
package com.springboot.react.config;

// 필요한 Spring Framework 클래스들을 임포트합니다.
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// @Configuration 어노테이션은 이 클래스가 스프링 설정 정보를 제공하는 클래스임을 나타냅니다.
// 스프링은 이 클래스를 구성 요소로 사용하여 빈 설정이나 다른 설정을 초기화할 때 활용합니다.
@Configuration

// WebConfig 클래스는 WebMvcConfigurer 인터페이스를 구현하여
// Spring MVC를 위한 추가적인 구성(예: CORS, 포맷터, 인터셉터 등)을 제공합니다.
public class WebConfig implements WebMvcConfigurer {

    // addCorsMappings 메소드는 CORS(Cross-Origin Resource Sharing) 관련 설정을 정의합니다.
    // 이 메소드는 WebMvcConfigurer 인터페이스의 메소드를 오버라이드하여 사용됩니다.
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // registry.addMapping("/**")는 모든 경로에 대해 CORS 정책을 설정하겠다는 것을 의미합니다.
        registry.addMapping("/**")
                // .allowedOrigins 메소드는 특정 출처(origin)에서 들어오는 요청을 허용하도록 설정합니다.
                // 이 경우, "http://192.168.10.200:3000"와 "http://localhost:3000" 두 출처가 허용됩니다.
        		.allowedOrigins("http://192.168.10.200:3000", "http://localhost:3000")
                // .allowedMethods 메소드는 허용할 HTTP 메소드를 설정합니다.
                // GET, POST, PUT, DELETE, OPTIONS 메소드가 허용됩니다.
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                // .allowedHeaders 메소드는 요청에서 허용할 헤더를 설정합니다.
                // "*"는 모든 헤더를 허용함을 의미합니다.
                .allowedHeaders("*")
                // .allowCredentials 메소드는 인증 정보(예: 쿠키, HTTP 인증, 클라이언트 SSL 인증 등)의 전송을 허용할지 설정합니다.
                // true로 설정하면 인증 정보의 전송을 허용합니다.
                .allowCredentials(true);
    }
}
